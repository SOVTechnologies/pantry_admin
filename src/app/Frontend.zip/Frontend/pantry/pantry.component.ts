import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
interface PantryStatus {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-pantry',
  templateUrl: './pantry.component.html',
  styleUrls: ['./pantry.component.scss']
})
export class PantryComponent implements OnInit {

  pantryForm: FormGroup;
  listData: any;

  inputnumber: number = 0;  
  closeResult = '';


  constructor(private fb: FormBuilder, public modalService: NgbModal) { 

    this.listData = [];
    this.pantryForm = this.fb.group({
    roomNo: [''],
    name: [''],
    quantity: [''],
    description: [''],

  })

  }

  ngOnInit() {
  }

  pantryStatus: PantryStatus[] = [

    { value: 'Active', viewValue: 'Active' },
    { value: 'Pending', viewValue: 'Pending' },
    { value: 'Out of Stock', viewValue: 'Out Of Stock' }

  ];

  public addRow(): void {
    this.listData.push(this.pantryForm.value);
    this.pantryForm.reset();
    // this.reset();

    this.modalService.dismissAll("submit");
  }

  // reset() {
  //   this.userForm.reset;
  // }

  remove(element: any) {
    this.listData.forEach((value: any, index: any) => {
      if (value == element)
        this.listData.splice(index, 1);
    });
  }

  editDialog(element: { [x: string]: any; }) {
    this.listData.forEach((value: { [x: string]: any; }, index: any) => {
      if (value == element) {
        
        this.pantryForm = this.fb.group({
          roomNo: (element['roomNo']),
          name: (element['name']),
          quantity: (element['quantity']),
          description: (element['description']),
        })
        
      }
      
    });
    this.remove(element);

  }

  plus(){
    this.inputnumber = this.inputnumber + 1;
  }
  minus(){
    if(this.inputnumber != 0){
      this.inputnumber = this.inputnumber - 1;
    }
    
  }

  open(content: any) {
    this.modalService.open(content, {size: 'xl'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
    // this.modalService.open(content, {size: 'xl'},);
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

}
