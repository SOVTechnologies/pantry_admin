import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';


interface FloorOptions {
  value: string;
  viewValue: string;
}


interface TypeOptions {
  value: string;
  viewValue: string;
}


@Component({
  selector: 'app-meeting-room',
  templateUrl: './meeting-room.component.html',
  styleUrls: ['./meeting-room.component.scss']
})
export class MeetingRoomComponent implements OnInit {

  meetingForm: FormGroup;
  listData: any;

  closeResult = '';

  constructor(private fb: FormBuilder, public modalService: NgbModal) { 

    this.listData = [];

    this.meetingForm = this.fb.group({
      roomName: [''],
      floor: [''],
      capacity: [''],
      type: ['']
    })

  }

  ngOnInit() {
  }

  flooroptions: FloorOptions[] = [
    { value: 'First', viewValue: 'First' },
    { value: 'Second', viewValue: 'Second' }
  ];

  typeOption: TypeOptions[] = [
    { value: 'First', viewValue: 'Delux' },
    { value: 'Second', viewValue: 'Royal' }
  ];

  public addRow(): void {
    this.listData.push(this.meetingForm.value);
    this.meetingForm.reset();
    // this.reset();
    this.modalService.dismissAll("submit");
  }

  remove(element: any) {
    this.listData.forEach((value: any, index: any) => {
      if (value == element)
        this.listData.splice(index, 1);
    });
  }

  editDialog(element: { [x: string]: any; }) {
    this.listData.forEach((value: { [x: string]: any; }, index: any) => {
      if (value == element) {
        
        this.meetingForm = this.fb.group({
          roomName: (element['roomName']),
          floor: (element['floor']),
          capacity: (element['capacity']),
          type: (element['type'])
        })
        
      }
      
    });
    this.remove(element);

  }

  open(content: any) {
    this.modalService.open(content, {size: 'xl'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
    // this.modalService.open(content, {size: 'xl'},);
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
}